1）解压ip.tar.gz至hw工作路径
2）新建rfsoc27dr vivado工程，引入ip内的2个.v文件
3）运行design_1.tcl
4）应用example_design.xdc
5)  生成bitstream