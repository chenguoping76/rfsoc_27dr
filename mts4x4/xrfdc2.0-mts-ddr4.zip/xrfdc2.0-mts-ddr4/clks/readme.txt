如果需要使用不同的lmx，
如对ADC T0, T1配置为256.0MHz
      ADC T2, T3配置为128.0MHz

      DACT0,T1配置为409.6MHz

则在此目录下新增lmk04208目录，然后cp 4个文件：
     LMK04208_122.88.TXT
     LMXA2594_256.0.TXT
     LMXB2594_128.0.TXT
     LMXC2594_409.6.TXT

上述文件由TICS Pro生成，文件名中的A，B，C对应ADC T0T1，ADC T2T3，DACT0T1

在notebook里调用clocks.set_custom_lmclks(loc), loc= ‘此目录位置’
	