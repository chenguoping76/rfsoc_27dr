
1. xrfdc包含mts支持的rfsoc-pynq 镜像 链接：https://pan.baidu.com/s/1j9NsirzMEF9v5rLuvE0MVw?pwd=w04w 
    下载RFSOC27DR-3.0.1-V2.0.zip，使用balenaEtcher_v1.7.2 写入32G超高速sd卡
2. 启动pynq，打开一个terminal #chmod 777 /home/xilinx/jupyter_notebook
3. cp 本release，解压至/home/xilinx/jupyter_notebook/xrfdc2.0-mts-ddr4
4. 打开rfsocMTS.ipynb