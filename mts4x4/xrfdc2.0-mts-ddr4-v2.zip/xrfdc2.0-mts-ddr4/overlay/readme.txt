在rfsoc27dr上重新构建MTS

1)  解压rfsoc27dr_mts_src
2）vivado 2022.1
3)  新建27dr项目
4）引入rfsoc27dr_mts_src\ip\rtl\*.v 源文件
5）运行design_3.tcl
6)  使用27dr_ddr4.xdc 约束
7）生成bitstream
8)  使用或编辑dts1\ddr4.dts，完成后使用make生成dtbo